﻿CREATE TABLE [dbo].[dim_teste]
(
	[Id] INT NOT NULL PRIMARY KEY
)
